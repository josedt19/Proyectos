"""Punto de entrada de la API de MatchMind."""
import os

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from .config import settings
from .routers import health

app = FastAPI(title="MatchMind API", version="0.1.0")
app.include_router(health.router, prefix="/api")

# Sirve el frontend solo si existe frontend/index.html (en minúsculas, Linux distingue mayúsculas).
if os.path.isfile(os.path.join(settings.frontend_dir, "index.html")):
    app.mount("/", StaticFiles(directory=settings.frontend_dir, html=True), name="frontend")
