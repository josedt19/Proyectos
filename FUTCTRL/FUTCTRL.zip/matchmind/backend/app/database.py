"""Conexión con PostgreSQL. No conecta hasta que se hace la primera consulta."""
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, sessionmaker

from .config import settings

engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False)


class Base(DeclarativeBase):
    """Clase base de todos los modelos (se añadirán en la Fase 1)."""


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
