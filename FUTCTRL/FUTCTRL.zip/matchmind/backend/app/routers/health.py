"""Comprobaciones de salud: /api/health (la API vive) y /api/health/db (la base de datos responde)."""
import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db

router = APIRouter(tags=["salud"])
log = logging.getLogger("matchmind")


@router.get("/health")
def health():
    return {"estado": "ok", "servicio": "matchmind-api", "entorno": settings.app_env}


@router.get("/health/db")
def health_db(db: Session = Depends(get_db)):
    try:
        version = db.execute(text("SELECT version()")).scalar_one()
    except SQLAlchemyError as exc:
        log.error("Fallo al conectar con la base de datos: %s", exc)  # detalle completo en los logs
        raise HTTPException(status_code=503, detail=f"Base de datos no disponible ({type(exc).__name__}). Revisa los logs de la API.")
    return {"estado": "ok", "base_de_datos": "conectada", "version": version}
