"""Configuración leída de variables de entorno (archivo .env).
Los campos sin valor por defecto son obligatorios: si faltan, la app falla al arrancar y lo dice."""
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import URL


class Settings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")

    app_env: str = "development"
    postgres_user: str
    postgres_password: str
    postgres_db: str
    postgres_host: str = "db"
    postgres_port: int = 5432
    frontend_dir: str = "/frontend"

    @property
    def database_url(self) -> URL:
        # URL.create escapa bien los caracteres especiales de la contraseña.
        return URL.create(
            "postgresql+psycopg",
            username=self.postgres_user,
            password=self.postgres_password,
            host=self.postgres_host,
            port=self.postgres_port,
            database=self.postgres_db,
        )


settings = Settings()
