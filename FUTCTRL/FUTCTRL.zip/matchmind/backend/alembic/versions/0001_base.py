"""base sin tablas

Revision ID: 0001
Revises:
Create Date: 2026-10-14
"""
revision = "0001"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass  # punto de partida: las tablas llegan en la Fase 1


def downgrade():
    pass
