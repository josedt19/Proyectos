"use strict";
/* MatchMind · frontend inicial.
   NO hay backend: los datos son de DEMOSTRACIÓN y se guardan solo en este navegador (localStorage).
   Cuando exista la API, los datos y el cálculo de puntos pasarán al servidor. */
const KEY = "matchmind_demo_v1", QS = new URLSearchParams(location.search), PAGE = document.body.dataset.page;
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- Datos DEMO (equipos y jugadores ficticios) ---------- */
const TEAMS = ["Real Demo CF", "Atlético Ficticio", "Unión Muestra", "Deportivo Prueba", "Racing Simulado", "Sporting Ejemplo"];
const SUR = ["Alcázar", "Brais", "Cortés", "Dueñas", "Elorza", "Fariña", "Galán", "Hidalgo", "Ibarra", "Jover", "Lasso", "Mena", "Noriega", "Ochoa", "Pardo", "Quirós", "Roldán", "Sanz", "Tapia", "Uribe", "Vidal", "Yagüe", "Zubiri", "Arce"];
const POS = [..."PPDDDDDDCCCCCAAA"];                       // plantel de 16: 2 porteros, 6 defensas, 5 medios, 3 delanteros
const FORM = { "4-4-2": "PDDDDCCCCAA", "4-3-3": "PDDDDCCCAAA", "3-5-2": "PDDDCCCCCAA" };
const LAB = { P: "Portero", D: "Defensa", C: "Centrocampista", A: "Delantero" };
const squad = t => POS.map((p, i) => ({ id: t + "-" + i, n: SUR[(t * 3 + i) % SUR.length], p }));
const MS = [ // e = estado inicial, res = resultado DEMO que se aplica al finalizar
  { id: 1, j: 7, l: 0, v: 1, ini: "sáb 24 oct, 18:30", e: "programado", res: [2, 1] },
  { id: 2, j: 7, l: 2, v: 3, ini: "dom 25 oct, 16:00", e: "programado", res: [0, 0] },
  { id: 3, j: 7, l: 4, v: 5, ini: "dom 25 oct, 20:00", e: "alineaciones", res: [1, 3] },
  { id: 4, j: 6, l: 1, v: 2, ini: "sáb 17 oct, 18:30", e: "finalizado", res: [2, 2] }
];
const RT = [
  { id: 1, m: 1, q: "Tu equipo juega 4-4-2 y el rival presiona alto. ¿Qué ajuste ayuda a sacar el balón jugando?", o: ["Pelotazos largos siempre", "Un mediocentro baja entre los centrales", "Poner cuatro delanteros"], c: 1, x: "Bajar un mediocentro crea superioridad en la salida y ofrece un pase seguro." },
  { id: 2, m: 2, q: "¿Qué gana un 3-5-2 frente a un 4-4-2?", o: ["Más presencia en el centro del campo", "Siempre menos goles en contra", "Nada"], c: 0, x: "Cinco centrocampistas dan superioridad en el medio; a cambio, los carrileros cubren mucha banda." },
  { id: 3, m: null, q: "¿Qué significa jugar con la línea defensiva adelantada?", o: ["Los defensas se alejan de su portería para reducir espacios", "Los defensas dejan de marcar", "El portero juega de delantero"], c: 0, x: "Reduce el espacio entre líneas, pero deja espacio a la espalda si el rival rompe el fuera de juego." }
];
const DEMOU = [["Marta_Demo", 42], ["Álex_Demo", 37], ["Lucía_Demo", 31], ["Hugo_Demo", 24], ["Sara_Demo", 12]];
const EST = { programado: ["Programado", ""], alineaciones: ["Alineaciones publicadas", "b-wa"], finalizado: ["Finalizado", "b-ok"] };
const ORD = ["programado", "alineaciones", "finalizado"];

/* ---------- Estado local ---------- */
let S; try { S = JSON.parse(localStorage.getItem(KEY)); } catch (e) { }
S = S || {}; ["pred", "lin", "ans", "est"].forEach(k => S[k] = S[k] || {});
const save = () => localStorage.setItem(KEY, JSON.stringify(S));
const estado = m => S.est[m.id] || m.e;
const abierto = m => estado(m) === "programado";
const get = id => MS.find(m => m.id == id);
const nm = m => TEAMS[m.l] + " – " + TEAMS[m.v];

/* ---------- Puntos (cálculo local de demostración) ---------- */
function oficial(t) { // alineación oficial DEMO: siempre la misma para cada equipo
  const f = t % 2 ? "4-3-3" : "4-4-2", ids = [];
  [...FORM[f]].forEach(p => ids.push(squad(t).find(j => j.p === p && !ids.includes(j.id)).id));
  return { f, ids };
}
function ptsPred(m) {
  const p = S.pred[m.id]; if (!p || estado(m) !== "finalizado") return null;
  if (p[0] === m.res[0] && p[1] === m.res[1]) return 5;
  return Math.sign(p[0] - p[1]) === Math.sign(m.res[0] - m.res[1]) ? 3 : 0;
}
function ptsLin(m, t) {
  const l = S.lin[m.id + ":" + t]; if (!l || estado(m) !== "finalizado") return null;
  const o = oficial(t);
  return Object.values(l.sl).filter(i => o.ids.includes(i)).length + (l.f === o.f ? 3 : 0);
}
function stats() {
  let pts = 0, pr = 0, ok = 0; const hist = [];
  MS.forEach(m => {
    const p = ptsPred(m);
    if (p !== null) { pts += p; pr++; if (p > 0) ok++; hist.push(["Predicción " + nm(m), p]); }
    [m.l, m.v].forEach(t => { const q = ptsLin(m, t); if (q !== null) { pts += q; hist.push(["Once de " + TEAMS[t] + " en " + nm(m), q]); } });
  });
  RT.forEach(r => { if (S.ans[r.id] !== undefined) { const g = S.ans[r.id] === r.c; if (g) pts += 2; hist.push(["Reto: " + r.q.slice(0, 45) + "…", g ? 2 : 0]); } });
  return { pts, pr, ok, hist, pct: pr ? Math.round(ok / pr * 100) + " %" : "—" };
}
const rank = () => DEMOU.map(u => [u[0], u[1], 0]).concat([["Tú", stats().pts, 1]]).sort((a, b) => b[1] - a[1]);

/* ---------- Componentes ---------- */
function shell(page, title, html) {
  const NAV = [["index", "Inicio"], ["partidos", "Partidos"], ["predicciones", "Predicciones"], ["entrenador", "Entrenador"], ["retos", "Retos"], ["clasificacion", "Clasificación"]];
  const MOB = ["index", "partidos", "entrenador", "retos", "clasificacion"];
  $("#app").innerHTML = `<a class="skip" href="#main">Saltar al contenido</a><div class="app">
<nav class="side" aria-label="Principal"><a class="brand" href="index.html">Match<b>Mind</b></a>${NAV.map(([p, t]) => `<a href="${p}.html" class="${MOB.includes(p) ? "" : "sec"}" ${p === page ? 'aria-current="page"' : ""}>${t}</a>`).join("")}</nav>
<div><header class="top"><a class="brand m" href="index.html">Match<b>Mind</b></a><span class="badge b-wa">Datos DEMO</span><span class="sp"></span><a href="perfil.html">Perfil</a><a href="admin.html">Admin</a><a class="btn" href="login.html">Entrar</a></header>
<main id="main"><h1>${title}</h1>${html}</main></div></div><div id="toast" role="status" aria-live="polite"></div>`;
  document.title = title + " | MatchMind";
}
const toast = (msg, bad) => { const t = $("#toast"); t.textContent = msg; t.style.background = bad ? "var(--er)" : ""; t.classList.add("on"); setTimeout(() => t.classList.remove("on"), 2600); };
const badge = m => `<span class="badge ${EST[estado(m)][1]}">${EST[estado(m)][0]}</span>`;
const crest = t => `<span class="crest" aria-hidden="true">${TEAMS[t].split(" ").map(w => w[0]).slice(0, 2).join("")}</span>`;
const team = t => `<span class="tm">${crest(t)}${esc(TEAMS[t])}</span>`;
const card = m => `<a class="card mt" href="partido.html?id=${m.id}"><div>${team(m.l)}${team(m.v)}</div><div>${badge(m)}<div class="mu">Jornada ${m.j}, ${m.ini}</div></div></a>`;
const empty = t => `<p class="empty">${t}</p>`;
const notFound = () => shell("partidos", "No encontrado", `<p class="empty er">No existe ese partido. <a class="btn" href="partidos.html">Volver a partidos</a></p>`);
const histo = h => h.length ? `<ul class="ls">${h.slice(-6).reverse().map(x => `<li><span>${esc(x[0])}</span><b class="${x[1] ? "ac" : "mu"}">+${x[1]}</b></li>`).join("")}</ul>` : empty("Todavía no hay puntos. Haz una predicción o monta un once y finaliza el partido desde Admin (demo).");
function predForm(m) {
  const p = S.pred[m.id] || ["", ""], c = !abierto(m), pt = ptsPred(m), d = c ? "disabled" : "";
  return `<form class="pf" data-m="${m.id}"><div class="mt"><label class="tm">${esc(TEAMS[m.l])} <input class="num" type="number" min="0" max="20" name="a" value="${p[0]}" ${d} required aria-label="Goles de ${esc(TEAMS[m.l])}"></label><b>–</b><label class="tm"><input class="num" type="number" min="0" max="20" name="b" value="${p[1]}" ${d} required aria-label="Goles de ${esc(TEAMS[m.v])}"> ${esc(TEAMS[m.v])}</label></div>
<p class="mu">${c ? (pt === null ? "Predicciones cerradas para este partido." : "Resultado demo " + m.res.join("–") + ". Ganaste " + pt + " pts.") : "Puedes cambiarla hasta el cierre."}</p>${c ? "" : '<button class="btn btn-p">Guardar predicción</button>'}</form>`;
}
function siguiente() {
  const n = MS.find(abierto);
  if (!n) return { t: "No hay partidos abiertos ahora mismo.", h: "admin.html", b: "Abrir el panel demo" };
  if (!S.pred[n.id]) return { t: "Haz tu predicción", h: "partido.html?id=" + n.id, b: "Predecir" };
  if (!S.lin[n.id + ":" + n.l]) return { t: "Monta tu once", h: "entrenador.html?id=" + n.id, b: "Ir al entrenador" };
  return RT.some(r => S.ans[r.id] === undefined) ? { t: "Resuelve un reto", h: "retos.html", b: "Ver retos" } : { t: "Todo listo para este partido.", h: "clasificacion.html", b: "Ver clasificación" };
}
const statList = s => `<ul class="ls"><li><span>Puntos</span><b class="ac">${s.pts}</b></li><li><span>Predicciones resueltas</span><b>${s.pr}</b></li><li><span>Aciertos de resultado</span><b>${s.pct}</b></li><li><span>Retos respondidos</span><b>${Object.keys(S.ans).length}/${RT.length}</b></li></ul>`;
const rankTable = n => `<div class="sc"><table><thead><tr><th>Puesto</th><th>Usuario</th><th>Puntos</th></tr></thead><tbody>${rank().slice(0, n).map((u, i) => `<tr class="${u[2] ? "me" : ""}"><td>${i + 1}</td><td>${esc(u[0])} ${u[2] ? "" : '<span class="badge">demo</span>'}</td><td>${u[1]}</td></tr>`).join("")}</tbody></table></div>`;

/* ---------- Pantallas ---------- */
const P = {
  index() {
    const n = MS.find(abierto), s = stats(), a = siguiente(), pend = RT.filter(r => S.ans[r.id] === undefined).slice(0, 2);
    shell("index", "Tu próximo paso", `<div class="grid">
<section class="card hero wide" aria-label="Próximo partido">${n ? `<div class="mt">${team(n.l)}<span class="score">vs</span>${team(n.v)}</div><p class="mu">Jornada ${n.j}, ${n.ini} ${badge(n)}</p>` : empty("No hay partidos programados.")}<p><b>${a.t}</b></p><a class="btn btn-p" href="${a.h}">${a.b}</a></section>
<section class="card"><h2>Tu progreso</h2>${statList(s)}</section>
<section class="card"><h2>Retos disponibles</h2>${pend.length ? `<ul class="ls">${pend.map(r => `<li><span>${esc(r.q)}</span><a class="btn" href="retos.html#r${r.id}">Responder</a></li>`).join("")}</ul>` : empty("Has respondido todos los retos.")}</section>
<section class="card"><h2>Clasificación</h2>${rankTable(5)}<p><a class="ac" href="clasificacion.html">Ver clasificación completa</a></p></section>
<section class="card"><h2>Últimos puntos</h2>${histo(s.hist)}</section></div>`);
  },
  partidos() {
    const js = [...new Set(MS.map(m => m.j))].sort((a, b) => b - a);
    shell("partidos", "Partidos", `<p class="mu">Todos los partidos son de demostración. <a class="ac" href="predicciones.html">Ver todas mis predicciones</a></p>${js.map(j => `<h2>Jornada ${j}</h2><div class="grid">${MS.filter(m => m.j === j).map(card).join("")}</div>`).join("")}`);
  },
  partido() {
    const m = get(QS.get("id")); if (!m) return notFound();
    const ret = RT.filter(r => r.m === m.id), fin = estado(m) === "finalizado";
    shell("partidos", esc(nm(m)), `<div class="grid">
<section class="card hero wide"><div class="mt">${team(m.l)}<span class="score">${fin ? m.res.join(" – ") : "vs"}</span>${team(m.v)}</div><p class="mu">Jornada ${m.j}, ${m.ini} ${badge(m)}</p>${fin ? '<p class="mu">Resultado de demostración, no es un partido real.</p>' : ""}</section>
<section class="card"><h2>Tu predicción</h2>${predForm(m)}</section>
<section class="card"><h2>Tu alineación táctica</h2><ul class="ls">${[m.l, m.v].map(t => { const l = S.lin[m.id + ":" + t], p = ptsLin(m, t); return `<li><span>${esc(TEAMS[t])}: ${l ? l.f + (p !== null ? ", " + p + " pts" : ", guardada") : "sin hacer"}</span><a class="btn" href="entrenador.html?id=${m.id}&t=${t}">${abierto(m) ? (l ? "Editar" : "Montar once") : "Ver"}</a></li>`; }).join("")}</ul></section>
<section class="card"><h2>Retos del encuentro</h2>${ret.length ? `<ul class="ls">${ret.map(r => `<li><span>${esc(r.q)}</span><a class="btn" href="retos.html#r${r.id}">${S.ans[r.id] === undefined ? "Responder" : "Ver"}</a></li>`).join("")}</ul>` : empty("Este partido aún no tiene retos.")}</section>
${abierto(m) ? "" : `<section class="card wide"><h2>Alineaciones oficiales (demo) y aprendizaje</h2><p class="mu">En verde, los jugadores que también elegiste tú.</p>${[m.l, m.v].map(t => { const o = oficial(t), mi = S.lin[m.id + ":" + t], mine = mi ? Object.values(mi.sl) : []; return `<h3>${esc(TEAMS[t])}, oficial ${o.f}${mi ? " (tu formación: " + mi.f + ")" : ""}</h3><div class="chips">${o.ids.map(i => { const j = squad(t).find(x => x.id === i); return `<span class="chip ${mine.includes(i) ? "hit" : ""}">${j.p} ${esc(j.n)}</span>`; }).join("")}</div>`; }).join("")}</section>`}</div>`);
  },
  predicciones() {
    shell("predicciones", "Predicciones", `<p class="mu">Acertar el resultado da 3 pts y el marcador exacto 5 pts (reglas de demostración, ajustables).</p><div class="grid">${MS.map(m => `<section class="card"><div class="mt"><span class="mu">Jornada ${m.j}</span>${badge(m)}</div>${predForm(m)}<p><a class="ac" href="partido.html?id=${m.id}">Detalle del partido</a></p></section>`).join("")}</div>`);
  },
  entrenador() {
    const m = get(QS.get("id")) || MS.find(abierto) || MS[0]; let t = QS.get("t"); t = t !== null && [m.l, m.v].includes(+t) ? +t : m.l;
    const sv = S.lin[m.id + ":" + t], f = FORM[QS.get("f")] ? QS.get("f") : (sv ? sv.f : "4-4-2"), sq = squad(t), cl = !abierto(m);
    const row = p => { const n = [...FORM[f]].filter(x => x === p).length; return `<div class="row">${Array.from({ length: n }, (_, i) => `<label class="slot">${p}<select data-k="${p}${i}" ${cl ? "disabled" : ""} aria-label="${LAB[p]} ${i + 1}"><option value="">—</option>${sq.filter(j => j.p === p).map(j => `<option value="${j.id}" ${sv && sv.f === f && sv.sl[p + i] === j.id ? "selected" : ""}>${esc(j.n)}</option>`).join("")}</select></label>`).join("")}</div>`; };
    shell("entrenador", "Modo entrenador", `<div class="grid"><section class="card"><h2>Partido, equipo y formación</h2><div class="f">
<label>Partido<select id="sm">${MS.map(x => `<option value="${x.id}" ${x.id === m.id ? "selected" : ""}>${esc(nm(x))} (J${x.j})</option>`).join("")}</select></label>
<label>Equipo<select id="st">${[m.l, m.v].map(x => `<option value="${x}" ${x === t ? "selected" : ""}>${esc(TEAMS[x])}</option>`).join("")}</select></label>
<label>Formación<select id="sf">${Object.keys(FORM).map(x => `<option ${x === f ? "selected" : ""}>${x}</option>`).join("")}</select></label></div>
<p class="mu">${cl ? "Este partido está cerrado: solo lectura." : "Elige un jugador por puesto. Cada coincidencia con el once oficial da 1 pt y acertar la formación da 3 pts."}</p>${cl ? "" : '<button class="btn btn-p" data-act="save-lin">Guardar alineación</button>'}</section>
<section class="card"><div class="pitch" id="pitch" data-m="${m.id}" data-t="${t}" data-f="${f}">${["A", "C", "D", "P"].map(row).join("")}</div></section></div>`);
  },
  retos() {
    shell("retos", "Retos", `<p class="mu">Cada reto acertado da 2 pts. Tras responder verás la explicación.</p><div class="grid">${RT.map(r => { const a = S.ans[r.id], d = a !== undefined; return `<form class="card rf" id="r${r.id}" data-r="${r.id}"><fieldset style="border:0;padding:0;margin:0" ${d ? "disabled" : ""}><legend><b>${esc(r.q)}</b></legend>${r.o.map((o, i) => `<label class="opt"><input type="radio" name="o" value="${i}" ${a === i ? "checked" : ""}> ${esc(o)}</label>`).join("")}</fieldset>${d ? `<p class="${a === r.c ? "ac" : "er"}"><b>${a === r.c ? "Correcto, +2 pts." : "Incorrecto. Correcta: " + esc(r.o[r.c]) + "."}</b> ${esc(r.x)}</p>` : '<button class="btn btn-p">Responder</button>'}${r.m ? `<p><a class="ac" href="partido.html?id=${r.m}">Ver el partido relacionado</a></p>` : ""}</form>`; }).join("")}</div>`);
  },
  clasificacion() { shell("clasificacion", "Clasificación", `<p class="mu">Los demás usuarios son datos de demostración. Tú apareces con los puntos de este navegador.</p><section class="card">${rankTable(20)}</section>`); },
  perfil() {
    const s = stats();
    shell("perfil", "Tu perfil", `<p class="note">Todavía no hay cuentas (Fase 2). Este progreso se guarda solo en este navegador.</p><div class="grid"><section class="card"><h2>Resumen</h2>${statList(s)}</section><section class="card"><h2>Historial</h2>${histo(s.hist)}</section><section class="card wide"><h2>Datos demo</h2><p class="mu">Borra predicciones, onces, respuestas y estados de partido guardados aquí.</p><button class="btn" data-act="reset">Reiniciar datos demo</button></section></div>`);
  },
  login() {
    const campos = x => `<fieldset disabled style="border:0;padding:0;margin:0" class="f">${x}<button class="btn btn-p">No disponible hasta la Fase 2</button></fieldset>`;
    shell("login", "Entrar o crear cuenta", `<p class="note">Las cuentas se implementarán en la Fase 2 junto con el backend. Los formularios están desactivados a propósito.</p><div class="grid"><section class="card"><h2>Iniciar sesión</h2>${campos('<label>Correo<input type="email"></label><label>Contraseña<input type="password"></label>')}</section><section class="card"><h2>Crear cuenta</h2>${campos('<label>Nombre de usuario<input></label><label>Correo<input type="email"></label><label>Contraseña<input type="password"></label>')}</section></div>`);
  },
  admin() {
    shell("admin", "Panel de administración", `<p class="note">Sin autenticación por ahora: solo controla los datos demo de este navegador. Con el backend exigirá rol de administrador.</p><section class="card"><h2>Estado de los partidos</h2><div class="sc"><table><thead><tr><th>Partido</th><th>Estado</th><th></th></tr></thead><tbody>${MS.map(m => `<tr><td>${esc(nm(m))}</td><td>${badge(m)}</td><td><button class="btn" data-act="adv" data-m="${m.id}" ${estado(m) === "finalizado" ? "disabled" : ""}>Avanzar estado</button></td></tr>`).join("")}</tbody></table></div><p class="mu">Al pasar a Finalizado se aplica el resultado demo y se calculan los puntos.</p></section>`);
  }
};

/* ---------- Eventos ---------- */
document.addEventListener("submit", e => {
  const f = e.target; e.preventDefault();
  if (f.classList.contains("pf")) {
    const m = get(f.dataset.m), a = +f.a.value, b = +f.b.value;
    if (!abierto(m)) return toast("Partido cerrado", 1);
    if (![a, b].every(n => Number.isInteger(n) && n >= 0 && n <= 20)) return toast("Usa goles entre 0 y 20.", 1);
    S.pred[m.id] = [a, b]; save(); toast("Predicción guardada (demo local)"); P[PAGE]();
  }
  if (f.classList.contains("rf")) {
    const o = f.querySelector("input:checked"); if (!o) return toast("Elige una opción.", 1);
    S.ans[f.dataset.r] = +o.value; save(); P[PAGE]();
  }
});
document.addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b) return; const a = b.dataset.act;
  if (a === "adv") { const m = get(b.dataset.m), i = ORD.indexOf(estado(m)); if (i < 2) { S.est[m.id] = ORD[i + 1]; save(); toast("Estado actualizado (demo local)"); P[PAGE](); } }
  if (a === "reset" && confirm("¿Borrar todos los datos demo guardados en este navegador?")) { localStorage.removeItem(KEY); location.reload(); }
  if (a === "save-lin") {
    const p = $("#pitch"), m = get(p.dataset.m); if (!abierto(m)) return toast("Partido cerrado", 1);
    const sl = {}; let ok = true;
    document.querySelectorAll("[data-k]").forEach(s => { if (!s.value) ok = false; sl[s.dataset.k] = s.value; });
    if (!ok || new Set(Object.values(sl)).size < 11) return toast("Completa los 11 puestos sin repetir jugadores.", 1);
    S.lin[m.id + ":" + p.dataset.t] = { f: p.dataset.f, sl }; save(); toast("Alineación guardada (demo local)"); P[PAGE]();
  }
});
document.addEventListener("change", e => {
  const i = e.target.id; if (!["sm", "st", "sf"].includes(i)) return;
  location.search = "?id=" + $("#sm").value + (i === "sm" ? "" : "&t=" + $("#st").value + "&f=" + $("#sf").value);
});

try { P[PAGE](); } catch (err) { console.error(err); $("#app").innerHTML = `<main style="padding:2rem"><p class="empty er">Algo ha fallado al mostrar esta pantalla. Recarga la página o reinicia los datos demo desde el perfil.</p></main>`; }
